/**
 *
 * Clase que genera objetos
 */
package mx.unam.fciencias.Entity;

import java.io.FileNotFoundException;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;
import mx.unam.fciencias.Boundary.Run;

public class GeneradorDeObjetos {

    /**
     * Método que genera los objetos en un archivo .txt.
     */
    public static void generarObjetos() {
        Random r = new Random();
        //DE AQUI TOMARE LOS OBJETOS PARA LUEGO GENERAR OTRO ARREGLO CON MAS DE
        //ELLOS
        String[] nombresDeObjetos = {"COMPUTADORA", "BOLSO", "TENIS", "CUADRO",
            "BALON", "LIBROS", "IMPRESORA", "ROMPECABEZAS", "DVDs", "TAZAS",
            "TELEVISION", "PIZARRON", "POSTALES", "MUEBLES", "CARPETAS",
            "ESTUFA", "GUITARRA", "PELUCHES", "FRASCOS", "VASOS", "PLATOS",
            "TENEDORES", "TELEGRAMA", "AUTO", "JUGUETES", "ABRIGOS"};
        //AQUI GUARDARE LOS NOMBRES SELECCIONADOS ALEATORIAMENTE DEL ARREGLO
        //nombresDeObjetos
        String objs = "";
        //AQUI GUARDARE TODOS LOS ID GENERADOS ALEATORIAMENTE
        String id = "";
        //DE AQUI TOMO LOS ELEMENTOS QUE CONSTITUYEN LOS ID        
        String cadena = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        for (int i = 0; i < 6000; i++) {
            id += cadena.charAt(r.nextInt(36));

            if ((id.length() + 1) % 7 == 0) {
                id += " ";
            }

            if (i < 1000) {
                objs += nombresDeObjetos[i
                        % nombresDeObjetos.length] + " ";
            }
        }

        StringTokenizer st1 = new StringTokenizer(objs);
        StringTokenizer st = new StringTokenizer(id);

        String alternativa = "10\n";
        while (st.hasMoreTokens()) {
            alternativa += st.nextToken() + " " + st1.nextToken() + " "
                    + (r.nextInt(10) + 1)
                    + "\n";
        }

        Escritor e = new Escritor();
        try {
            e.escribe(alternativa);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Run.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
