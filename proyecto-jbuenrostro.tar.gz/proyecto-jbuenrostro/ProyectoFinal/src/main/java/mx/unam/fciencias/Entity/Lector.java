/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.fciencias.Entity;

import java.io.FileNotFoundException;
import java.io.File;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import mx.unam.fciencias.Control.Empaquetamiento;

/**
 *
 * @author carlos
 */
public class Lector {

    public static void leeArchivo(String archivo) {
        File f = new File(archivo);
        Scanner sc;
        try {
            sc = new Scanner(f);

            System.out.println("TAMAÑO DE LOS CONTENEDORES: " + sc.next()
                    + "\nID\t" + "PRODUCTOS\t" + "TAMAÑO");
            while (sc.hasNext()) {
                System.out.println(sc.next() + "\t" + sc.next() + "\t"
                        + sc.next());
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(
                    Lector.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static ListaDoblementeLigada lee(String archivo) {
        File f = new File(archivo);
        Scanner sc;
        int tam = 0;
        ListaDoblementeLigada lista = new ListaDoblementeLigada();
        Articulo a;
        try {
            sc = new Scanner(f);
            tam = sc.nextInt();
            while (sc.hasNext()) {
                a = new Articulo(sc.next(), sc.next(), sc.nextInt());
                lista.agregar(a);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(
                    Lector.class.getName()).log(Level.SEVERE, null, ex);
        }
        ListaDoblementeLigada ldl;
        Empaquetamiento emp = new Empaquetamiento(tam);
        ldl = (ListaDoblementeLigada) emp.empacar(lista);
        return ldl;
    }
}
