/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.fciencias.Control;

import java.util.InputMismatchException;
import java.util.Scanner;
import mx.unam.fciencias.Entity.ArbolAVL;
import mx.unam.fciencias.Entity.Articulo;
import mx.unam.fciencias.Entity.Escritor;
import mx.unam.fciencias.Entity.GeneradorDeObjetos;
import mx.unam.fciencias.Entity.Lector;
import mx.unam.fciencias.Entity.ListaDoblementeLigada;

/**
 *
 * @author carlos
 */
public class Menu {

    public static void menu() {
        GeneradorDeObjetos.generarObjetos();
        ListaDoblementeLigada listaResultante;
        Scanner sc1 = new Scanner("data/Salida.txt");
        sc1.close();
        listaResultante = Lector.lee("data/Salida.txt");
        boolean flag = false;
        Scanner sc;
        int opcion;
        try {
            do {
                System.out.println("Sé bienvenido al programa de empaquetamiento.\n"
                        + "Elije el numero de alguna de las siguientes opciones: \n"
                        + "1) Mostrar la lista de objetos a empacar.\n"
                        + "2) Empacar.\n"
                        + "3) Buscar en un contenedor específico.\n"
                        + "4) Almacenar.\n"
                        + "5) Salir.");

                sc = new Scanner(System.in);
                opcion = sc.nextInt();

                switch (opcion) {
                    case 1:
                        Lector.leeArchivo("data/Salida.txt");
                        break;
                    case 2:
                        System.out.println("El total de paquetes a utilizar es: "
                                + listaResultante.longitud());
                        ArbolAVL auxiliar;
                        for (int i = 0; i < listaResultante.longitud(); i++) {
                            auxiliar = (ArbolAVL) listaResultante.obtener(i);
                            System.out.println("\n\nMostrando Paquete: "
                                    + (i + 1)
                                    + "\nID\t" + "Tamaño\t" + "Nombre\n"
                                    + auxiliar.recorridoInOrden());
                            System.out.println("Los articulos que caben "
                                    + "son: "
                                    + auxiliar.nodosTotales(auxiliar.getRaiz()));
                        }
                        break;
                    case 3:
                        menuDos(listaResultante);
                        break;
                    case 4:
                        menuTres(listaResultante);
                        break;
                    case 5:
                        flag = false;
                        break;
                    default:
                        System.out.println("¡ERROR!:OPCION FUERA DE RANGO");
                        break;
                }
            } while (flag);
        } catch (InputMismatchException ime) {
            System.out.println("¡ERROR MENU!:ENTRADA INVALIDA.");
        }
    }

    private static void menuDos(ListaDoblementeLigada listaResultante) {
        Scanner sc;
        int indice;
        ArbolAVL aux;
        try {
            System.out.println("Ingresa el numero del paquete que deseas ver:\n");
            sc = new Scanner(System.in);
            indice = sc.nextInt();
            aux = (ArbolAVL) listaResultante.obtener(indice - 1);
            System.out.println(aux.recorridoInOrden());
        } catch (InputMismatchException ime) {
            System.out.println("¡ERROR OBTENIENDO INDICE!:ENTRADA INVALIDA.");
        }
    }

    private static void menuTres(ListaDoblementeLigada listaResultante) {
        Scanner sc;
        String titulo;
        String contenido = "";
        ArbolAVL auxiliar;
        
        try {
            System.out.println("¿cómo quieres que se llame el archivo?\n");
            sc = new Scanner(System.in);
            titulo = sc.nextLine();
            Escritor escribe = new Escritor();

            for (int i = 0; i < listaResultante.longitud(); i++) {
                auxiliar = (ArbolAVL) listaResultante.obtener(i);
                contenido += "\n\nMostrando Paquete: "
                        + (i + 1)
                        + "\nID\t" + "Tamaño\t" + "Nombre\n"
                        + auxiliar.recorridoInOrden();
                contenido += "Los articulos que caben "
                        + "son: "
                        + auxiliar.nodosTotales(auxiliar.getRaiz());
            }
            
            escribe.escribe(contenido, titulo);
        } catch (InputMismatchException ime) {
            System.out.println("¡ERROR OBTENIENDO INDICE!:ENTRADA INVALIDA.");

        }
    }
}
