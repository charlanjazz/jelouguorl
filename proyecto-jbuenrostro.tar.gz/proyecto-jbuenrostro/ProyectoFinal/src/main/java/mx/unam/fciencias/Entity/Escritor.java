/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.fciencias.Entity;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

/**
 *
 * @author carlos
 */
public class Escritor {

    public void escribe(String dictado) throws FileNotFoundException {
        PrintWriter escribando;

        try {
            escribando = new PrintWriter("data/Salida.txt");
            escribando.println(dictado);
            escribando.close();
        } catch (FileNotFoundException fnfe) {
            System.out.println("No se pudo crear");
        }
    }
    
    public void escribe(String dictado,String titulo){
        PrintWriter escribando;

        try {
            escribando = new PrintWriter("data/" + titulo + ".txt");
            escribando.println(dictado);
            escribando.close();            
        } catch (FileNotFoundException fnfe) {
            System.out.println("No se pudo crear");
        }
    }
}
