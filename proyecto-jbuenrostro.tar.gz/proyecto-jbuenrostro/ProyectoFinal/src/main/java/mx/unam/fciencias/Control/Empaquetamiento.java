/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mx.unam.fciencias.Control;

import mx.unam.fciencias.Entity.ArbolAVL;
import mx.unam.fciencias.Entity.ListaDoblementeLigada;
import mx.unam.fciencias.Entity.Articulo;

/**
 *
 * @author carlos
 */
public class Empaquetamiento {

    public Empaquetamiento() {
        capacidadMaxima = 0;
    }

    public Empaquetamiento(int capacidadMaxima) {        
        this.capacidadMaxima = capacidadMaxima;
    }

    public ListaDoblementeLigada
            empacar(ListaDoblementeLigada lista) {
        if (lista.esVacia()) {
            System.out.println("¡ERROR!:¡No hay nada que empacar!");
        } else {
            listaDeArboles = new ListaDoblementeLigada();
            for (int i = 0; i < lista.longitud(); i++) {
                if (listaDeArboles.longitud() != 0) {     
                    Articulo ar = (Articulo) lista.obtener(i);
                    buscaElMejorArbol(listaDeArboles, ar);
                } else {
                    ArbolAVL avl = new ArbolAVL();
                    Articulo ar = (Articulo) lista.obtener(i);
                    avl.agregar(ar);
                    listaDeArboles.agregar(avl, ar.getTam());
                }
            }
        }
        return listaDeArboles;
    }

    private void buscaElMejorArbol(ListaDoblementeLigada listaDeArboles,
            Articulo ar) {

        int tope = listaDeArboles.longitud();
        ArbolAVL aux;
        boolean flag = false;
        for (int i = 0; i < tope; i++) {
            if ((listaDeArboles.obtenerCapacidad(i) + ar.getTam()) <= capacidadMaxima) {
                aux = (ArbolAVL) listaDeArboles.obtener(i);
                aux.agregar(ar);
                listaDeArboles.estableceCapacidad(listaDeArboles.obtener(i),
                        listaDeArboles.obtenerCapacidad(i) + ar.getTam());
                flag = true;
                break;
            }
        }

        if (!flag) {
            aux = new ArbolAVL();
            aux.agregar(ar);
            listaDeArboles.agregar(aux, ar.getTam());
        }
    }    
    private ListaDoblementeLigada listaDeArboles;
    private int capacidadMaxima;
}
