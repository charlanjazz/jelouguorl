package mx.unam.fciencias.Boundary;

import mx.unam.fciencias.Control.Menu;

/**
 * Solo debes correr esta clase para que inicie el programa.
 *
 */
public class Run {

    public static void main(String[] args) {
        Menu.menu();
    }
}
